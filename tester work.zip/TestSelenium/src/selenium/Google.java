package selenium;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import atu.testrecorder.ATUTestRecorder;
import atu.testrecorder.exceptions.ATUTestRecorderException;

public class Google {
	//WebDriver driver;
	ATUTestRecorder recoder;
	public static void main(String[] args) throws IOException, ATUTestRecorderException {
		
		  DateFormat dateFormat = new SimpleDateFormat("yy-MM-dd HH-mm-ss");
		  Date date = new Date();
		  
		  ATUTestRecorder recorder = new ATUTestRecorder("D:\\ScriptsVideo\\","TestVideo-"+dateFormat.format(date),false);
		  //To start video recording.
		  recorder.start();  

		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\semillero\\eclipse-workspace\\TestSelenium\\src\\drivers\\chromedriver.exe");
		
		
		WebDriver Jose = new ChromeDriver();
		
		Jose.get("https://www.google.com/");
		//Jose.manage().timeouts().implicitlyWait(15,TimeUnit.SECONDS);
		//Declare a WebDriverWait variable. In this example, we will use myWaitVar as the name of the variable.
		WebDriverWait myWaitVar = new WebDriverWait(Jose, 30);

		//Use myWaitVar with ExpectedConditions on portions where you need the explicit wait to occur. In this case, we will use explicit wait on the username input before we type the text tutorial onto it.
		myWaitVar.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='q']")));
		//Jose.findElement(By.id(�username�)).sendKeys(�tutorial�);
		Jose.findElement(By.xpath("//input[@name='q']")).sendKeys("pildoras informaticas");
		
		Jose.findElement(By.xpath("//div[@class='FPdoLc VlcLAe']//input[@name='btnK']")).click();
		
		
	
		File scrFile = ((TakesScreenshot)Jose).getScreenshotAs(OutputType.FILE); 
		FileUtils.copyFile(scrFile, new File("c:\\tmp\\screenshot"+dateFormat.format(date)+".png"));
		Jose.close();
		Jose.quit();
		recorder.stop();

	}

}
