package POMEbay;

import static POMEbay.PomEbay.*;

import java.io.IOException;

import org.junit.Test;

import atu.testrecorder.exceptions.ATUTestRecorderException;

public class ProbarEbay {

	@Test
	public void test() throws ATUTestRecorderException, InterruptedException, IOException {
	
		 
			grabarVideo();
			abrirPaginaDeEbay();
			tomarFoto();
			escribirEnElCampoDeBusqueda("");
			tomarFoto();
			buscarProducto();
			tomarFoto();
			seleccionarBusqueda();
			agregarAlCarritoDeCompras();
			//validacionDelCarrito();
			
			cerrarNavegador();
			
		 
		 
		 
		 
		
	
		 
		 }
	
		
	}


