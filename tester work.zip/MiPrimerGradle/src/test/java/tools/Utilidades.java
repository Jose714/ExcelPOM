package tools;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.Rectangle;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import static org.junit.Assert.*;

import atu.testrecorder.ATUTestRecorder;
import atu.testrecorder.exceptions.ATUTestRecorderException;

public class Utilidades {
	
	static WebDriver Jose;
	static By campoDeBusqueda = By.xpath(("//input[@name='q']"));
	static By botonBuscar = By.xpath("//div[@class='FPdoLc VlcLAe']//input[@name='btnK");
	static By usuario = By.xpath("//input[@placeholder='Usuario']");
	static By contrasena = By.xpath("//input[@placeholder='Contrase�a']");
	static By clickBotonIngresar = By.xpath("//button[@class='btn-login']");
	static By clickModuloDeNotas = By.xpath("//a[contains(text(),'SVGA')]");
	static By unacCampusVirtual = By.xpath("//h3[contains(text(),'UNAC - Campus Virtual')]");
	static By misCursos = By.xpath("//a[contains(text(),'Mis Cursos')]");
	static By arqutecturaDeComputadores = By.xpath("//a[contains(text(),'ARQUITECTURA DE COMPUTADORE...')]");
	
	
	static ATUTestRecorder recorder;
	static DateFormat dateFormat = new SimpleDateFormat("yy-MM-dd HH-mm-ss");
	static Date date = new Date();
	//creacion del robot y abrir el navegador
	public static void  abrirPaginaInicialDeGoogle() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\semillero\\eclipse-workspace\\TestSelenium\\src\\drivers\\chromedriver.exe");	
		Jose = new ChromeDriver();	
		Jose.manage().window().maximize();
		Jose.get("http://virtual.unac.edu.co/");
	}
	//grabar video
	public static void grabarVideo() throws ATUTestRecorderException, InterruptedException {
		
		  recorder = new ATUTestRecorder("D:\\ScriptsVideo\\","TestVideo-"+dateFormat.format(date),false);//terminar
		  //To start video recording.
		  recorder.start(); 
			
	}
	//para tomar las capturas
	public static void tomarFoto() throws IOException {
		  File scrFile = ((TakesScreenshot)Jose).getScreenshotAs(OutputType.FILE); 
		  FileUtils.copyFile(scrFile, new File("c:\\tmp\\screenshot"+dateFormat.format(date)+".png"));
		
	}
//cierra el navegador y la grabacion
	public static void cerrarNavegador() throws ATUTestRecorderException, InterruptedException {
		Jose.close();
		Thread.sleep(2000);
		Jose.quit();
		Thread.sleep(2000);
		recorder.stop();
	}
	//escribe en el campo de texto
	public static void escribirEnElCampoDeBusqueda(String cadenaBuscar) {
		Jose.findElement(campoDeBusqueda).sendKeys(cadenaBuscar);
	}
	//boton de busqueda
	public static void darClickEnElBotonBuscar() {
		Jose.findElement(botonBuscar).click();
	}
	//ingresar usuario campo de texto del campus
	public static void ingresarUsuario(String cadenaUsuario) {
		Jose.findElement(usuario).sendKeys(cadenaUsuario);;
	}
	//ingresar contrase�a del campus
	public static void ingresarContrasena(String cadenaContrasena) {
		Jose.findElement(contrasena).sendKeys(cadenaContrasena);;
	}
	//boton para ingresar al campus
	public static void hacerClickBotonIngresar() {
		Jose.findElement(clickBotonIngresar).click();
	}
	//para entrar al modulo de notas
	public static void hacerClickModuloDeNotas() throws InterruptedException {
		Jose.findElement(clickModuloDeNotas).click();
		Thread.sleep(2000);
	}
	//inicio de sesion campus
	public static void iniciarSesionCampusVirtualUnac(String cadenaUsuario,String cadenaContrasena) throws InterruptedException {
		Jose.findElement(usuario).sendKeys(cadenaUsuario);
		Thread.sleep(2000);
		Jose.findElement(contrasena).sendKeys(cadenaContrasena);
		Thread.sleep(2000);
		Jose.findElement(clickBotonIngresar).click();
		
	}
	public static void buscarEnGoogle(String cadenaBuscar) throws InterruptedException {
		Jose.findElement(campoDeBusqueda).sendKeys(cadenaBuscar);
		Thread.sleep(2000);
		Jose.findElement(botonBuscar).click();
		//Actions actions = new Actions(Jose);
		//actions.moveToElement((WebElement) botonBuscar).click().build().perform();
	}
	public static void entrarLinkUnacCampusVirtual() {
		Jose.findElement(unacCampusVirtual).click();
	}
	public static void entrarMisCursos() throws InterruptedException {
		Jose.findElement(misCursos).click();
		Thread.sleep(2000);
	}
	public static void entrarArquitecturaDeComputadores() throws InterruptedException {
		Jose.findElement(arqutecturaDeComputadores).click();
		Thread.sleep(2000);
	}
	
	public static void validacionModuloDeNotas() {
		 String modulo = Jose.findElement(By.xpath("//a[contains(@title,'Sistema Virtual de Gesti�n Acad�mica')]")).getText();
		Assert.assertEquals("LOS VALORES OBTENIDOS NO SON IGUALES", modulo, "SVG");
		System.out.println(modulo);
	}
	
}
