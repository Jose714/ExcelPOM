package POMGoogle;

import static org.junit.Assert.*;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import static POMGoogle.Google.*;


public class ProbarGoogle {
	

	private WebDriver Jose;
	@Before
	public void setUp() throws Exception {
		abrirPaginaInicialDeGoogle();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		
		escribirEnElCampoDeBusqueda("Sophos solutions");
		darClickEnElBotonBuscar();
		
	}
 
}
