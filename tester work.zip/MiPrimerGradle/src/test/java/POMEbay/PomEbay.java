package POMEbay;

import java.io.File;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import atu.testrecorder.ATUTestRecorder;
import atu.testrecorder.exceptions.ATUTestRecorderException;

public class PomEbay {
	static WebDriver Jose;
	static By campoDeBusqueda = By.xpath(("//input[@id='gh-ac']"));
	static By botonBuscarProducto = By.xpath("//input[@id='gh-btn']");
	static By agregarAlCarrito = By.xpath("//a[@id='isCartBtn_btn']");
	static By primerlink = By.xpath("//a[@class='s-item__link'][1]");
	static By linkRegistrarme = By.xpath("//a[contains(text(),'reg�strate')]");
	static By menuColor = By.xpath("//select[contains(@id='msku-sel-1']");
	static By seleccionColor = By.id("msku-opt-1");
	static By miCarrito = By.xpath("//*[@class='gh-cart-icon']");
	static By relojEnElCarrito = By.xpath("//h1[@id='itemTitle']");
	static By deLaBusqueda = By.xpath("//h1[@id='itemTitle']");
	By validacion = By.xpath("//span[@class='BOLD']");

	
	static ATUTestRecorder recorder;
	static DateFormat dateFormat = new SimpleDateFormat("yy-MM-dd HH-mm-ss");
	static Date date = new Date();
	public static void grabarVideo() throws ATUTestRecorderException, InterruptedException {
		
		  recorder = new ATUTestRecorder("D:\\ScriptsVideo\\","TestVideo-"+dateFormat.format(date),false);//terminar
		  //To start video recording.
		  recorder.start(); 
			
	}
	public static void tomarFoto() throws IOException {
		  File scrFile = ((TakesScreenshot)Jose).getScreenshotAs(OutputType.FILE); 
		  FileUtils.copyFile(scrFile, new File("c:\\tmp\\screenshot"+dateFormat.format(date)+".png"));
		
	}
	public static void cerrarNavegador() throws ATUTestRecorderException, InterruptedException {
		Jose.close();
		Thread.sleep(2000);
		Jose.quit();
		Thread.sleep(2000);
		recorder.stop();
	}
	public static void  abrirPaginaDeEbay() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\semillero\\eclipse-workspace\\TestSelenium\\src\\drivers\\chromedriver.exe");	
		Jose = new ChromeDriver();	
		Jose.manage().window().maximize();
		Jose.get("https://www.ebay.com/");
	}
	
	public static void escribirEnElCampoDeBusqueda(String escribir) {
		Jose.findElement(campoDeBusqueda).sendKeys(escribir);
	}
	public static void buscarProducto() {
		Jose.findElement(botonBuscarProducto).click();
	}
	
	public static void agregarAlCarritoDeCompras() {
		Jose.findElement(agregarAlCarrito).click();
	}
	public static void menuSeleccionarcolor() {
		Jose.findElement(menuColor).click();
	}
	public static void colorDeReloj() {
		Jose.findElement(seleccionColor).click();
	}
	
	public static void seleccionarBusqueda() {
		Jose.findElement(primerlink).click();;
	}
	public static void validacionDelCarrito() {
		//String modulo = Jose.findElement(By.xpath("//h1[contains(@id,'itemTitle")).getText();
		String modulo1 = Jose.findElement(By.xpath("//h3[contains(text(),'Banpresto rey de una pieza de la artista Snakeman')]")).getText();
		//System.out.println(modulo);
		Assert.assertEquals(modulo1, "Banpresto rey de una pieza de la artista Snakeman");
		 System.out.println(modulo1);
		//Assert.assertEquals(Jose.findElement( deLaBusqueda).getText(), Jose.findElement(relojEnElCarrito).getText());
		
	}
	
}
