package mongoTest;

import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

class ProbarMongo {



	@Test
	void test() {
		WebDriver Jose;
		System.setProperty("webdriver.chrome.driver","C:\\Users\\semillero\\eclipse-workspace\\TestSelenium\\src\\drivers\\chromedriver.exe");	
		Jose = new ChromeDriver();	
		Jose.manage().window().maximize();
		Jose.get("https://www.ebay.com/");
		Jose.findElement(By.xpath("//a[contains(text(),'Inicia sesi�n')]")).click();;
		Jose.findElement(By.xpath("//div//span/input[contains(@id,'userid')]")).sendKeys("elbichocr714@gmail.com");;
		Jose.findElement(By.xpath("//div//span/input[contains(@id,'pass')]")).sendKeys("12345mil");;
		Jose.findElement(By.xpath("//button[@id='sgnBt']")).click();;
	}

}
