import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring.xml"})
public class MongoTest {

    private EmbeddedMongo embeddedMongo;

    @Autowired
    private MongoTemplate mongoTemplate;

    @Before public void setUp() throws Exception {
        embeddedMongo = new EmbeddedMongo();
        embeddedMongo.start();
    }

    @Test public void should_write_in_mongo() {
        Assert.assertNotNull(mongoTemplate);
        A a = new A();
        a.id = "1";
        mongoTemplate.save(a);

        A b = mongoTemplate.findAll(A.class).get(0);
        Assert.assertEquals("1",b.id);
    }

    @After public void tearDown() {
        embeddedMongo.stop();
    }

    public static class A {
        String id;

    }
}