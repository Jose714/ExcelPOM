package MiPrimerGradle;

import static org.junit.Assert.*;

import java.io.IOException;
import org.junit.Assert;
import org.junit.Test;
import atu.testrecorder.exceptions.ATUTestRecorderException;
import static tools.Utilidades.*;

public class ProbarGoogle  {

	@Test
	public void test() throws IOException, InterruptedException, ATUTestRecorderException {
		abrirPaginaInicialDeGoogle();
		grabarVideo();
		//buscarEnGoogle("Virtual unac");
		//escribirEnElCampoDeBusqueda("Virtual unac");
		//darClickEnElBotonBuscar();
		//entrarLinkUnacCampusVirtual();
		tomarFoto();
		iniciarSesionCampusVirtualUnac("20161023390","20041993771");
		tomarFoto();
		entrarMisCursos();
		tomarFoto();
		entrarArquitecturaDeComputadores();
		hacerClickModuloDeNotas();
		tomarFoto();
		validacionModuloDeNotas();	
		cerrarNavegador();
				   
	}
		
	}

