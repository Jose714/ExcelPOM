package mongoTest;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;




public class Conexion {
	DB baseDatos;
	DBCollection coleccion;
	BasicDBObject documento = new BasicDBObject();
	
public Conexion() {
	try {
		
		MongoClient mongo = new MongoClient("localhost",27017);
		baseDatos = mongo.getDB("BuscarEnGoogle");
		coleccion = baseDatos.getCollection("consultas");
		System.out.println("conectado a la base de datos satisfactoriamente");
	} catch (Exception e) {
		Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE,null,e);
		
	}
}
	public boolean insertar(String nombre) {
		documento.put("nombre", nombre);
		coleccion.insert(documento);
		return true;
		
	}
	
	public void mostrar() {
	DBObject cursor = coleccion.findOne();
	//while(cursor.hasNext()) {
		System.out.println("los datos son "+cursor);
		System.out.println();
	
	}
	
	public void buscarEnGoogle() {
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\semillero\\eclipse-workspace\\TestSelenium\\src\\drivers\\chromedriver.exe");
		DBObject cursor = coleccion.findOne();
		//while(cursor.hasNext()) {
			System.out.println("los datos son "+cursor);
			
		
		WebDriver Jose = new ChromeDriver();
		
		Jose.get("https://www.google.com/");
		//Jose.manage().timeouts().implicitlyWait(15,TimeUnit.SECONDS);
		
		
		//Jose.findElement(By.id(�username�)).sendKeys(�tutorial�);
		Jose.findElement(By.xpath("//input[@name='q']")).sendKeys(cursor.toString());
		
		Jose.findElement(By.xpath("//div[@class='FPdoLc VlcLAe']//input[@name='btnK']")).click();
	}

}
