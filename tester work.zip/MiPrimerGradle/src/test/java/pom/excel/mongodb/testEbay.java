package pom.excel.mongodb;
import java.io.IOException;

import static pom.excel.mongodb.Conexion.*;
import static pom.excel.mongodb.Google.*;
import org.junit.Test;

public class testEbay {




	@Test
	public void test() throws IOException, InterruptedException {
		
			abrirPaginaInicialDeGoogle();
			escribirEnElCampoDeBusqueda(obtenerDatosDeExcel());
			 darClickEnElBotonBuscar();	
		
		
	}
}


