package mongoTest;




public class MongoAutomation{
   public static void main( String args[] ){
     
Conexion conectar = new Conexion();
//conectar.insertar("Miller");
conectar.mostrar();
//conectar.buscarEnGoogle();
   }
}