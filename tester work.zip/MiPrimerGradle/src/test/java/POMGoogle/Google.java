package POMGoogle;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Google {
	static WebDriver Jose;
	static By campoDeBusqueda = By.xpath(("//input[@name='q']"));
	static By botonBuscar = By.xpath("//div[@class='FPdoLc VlcLAe']//input[@name='btnK']");
	
	public static void escribirEnElCampoDeBusqueda(String cadenaBuscar) {
		Jose.findElement(campoDeBusqueda).sendKeys(cadenaBuscar);
	}
	
	public static void darClickEnElBotonBuscar() {
		Jose.findElement(botonBuscar).click();
	}
	
	public static void abrirPaginaInicialDeGoogle() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\semillero\\eclipse-workspace\\TestSelenium\\src\\drivers\\chromedriver.exe");
		
		Jose = new ChromeDriver();
		Jose.manage().window().maximize();
		Jose.get("https://www.google.com/");
	}
	

}
